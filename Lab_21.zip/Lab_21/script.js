document.addEventListener('DOMContentLoaded', function() {
    const createProductBtn = document.getElementById('createProductBtn');
    const modal = document.getElementById('editProductModal');
    const closeBtn = modal.querySelector('.close');
    const saveProductBtn = document.getElementById('saveProductBtn');
    const productContainer = document.getElementById('productContainer');
  
    function openModal() {
      modal.style.display = 'block';
    }
  
    function closeModal() {
      modal.style.display = 'none';
    }
  
    createProductBtn.addEventListener('click', function() {
      openModal();
    });
  
    closeBtn.addEventListener('click', function() {
      closeModal();
    });
  
    window.addEventListener('click', function(event) {
      if (event.target == modal) {
        closeModal();
      }
    });
  
    saveProductBtn.addEventListener('click', function(event) {
      event.preventDefault(); 

      const productName = document.getElementById('productName').value;
      const productPrice = document.getElementById('productPrice').value;
      const productDesc = document.getElementById('productDesc').value;
      const productBrand = document.getElementById('productBrand').value;
      const productCategory = document.getElementById('productCategory').value;
      const productImageURL = document.getElementById('productImageURL').value;
  
 
      createProductCard(productName, productPrice, productDesc, productBrand, productCategory, productImageURL);

      closeModal();
    });
  
    function createProductCard(productName, productPrice, productDesc, productBrand, productCategory, productImageURL) {
      const productCard = document.createElement('div');
      productCard.classList.add('product-card');
  
      const productImage = document.createElement('img');
      productImage.src = productImageURL;
      productCard.appendChild(productImage);
  
      const productNameDisplay = document.createElement('p');
      productNameDisplay.textContent = productName;
      productCard.appendChild(productNameDisplay);
  
      const productPriceDisplay = document.createElement('p');
      productPriceDisplay.textContent = 'Ціна: ' + productPrice;
      productCard.appendChild(productPriceDisplay);
  
      const productDescDisplay = document.createElement('p');
      productDescDisplay.textContent = 'Опис: ' + productDesc;
      productCard.appendChild(productDescDisplay);
  
      const productBrandDisplay = document.createElement('p');
      productBrandDisplay.textContent = 'Бренд: ' + productBrand;
      productCard.appendChild(productBrandDisplay);
  
      const productCategoryDisplay = document.createElement('p');
      productCategoryDisplay.textContent = 'Категорія: ' + productCategory;
      productCard.appendChild(productCategoryDisplay);
  
      productContainer.appendChild(productCard);
    }
  });
  